#!/bin/sh
#
# name: Log Out
# icon: system-log-out
# description: Log out to the login screen
# keywords: log out logout

gnome-session-quit --logout
