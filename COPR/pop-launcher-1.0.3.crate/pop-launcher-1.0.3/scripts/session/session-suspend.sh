#!/bin/sh
#
# name: Suspend
# icon: system-suspend
# description: Suspend the system
# keywords: suspend

systemctl suspend