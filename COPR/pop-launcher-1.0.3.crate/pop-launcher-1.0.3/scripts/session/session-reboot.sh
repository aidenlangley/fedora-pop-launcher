#!/bin/sh
#
# name: Restart
# icon: system-restart
# description: Reboot the system
# keywords: power reboot restart

gnome-session-quit --reboot