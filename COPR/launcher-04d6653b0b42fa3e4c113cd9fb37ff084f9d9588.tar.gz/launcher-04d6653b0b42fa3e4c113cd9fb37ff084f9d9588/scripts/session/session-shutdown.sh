#!/bin/sh
#
# name: Power off
# icon: system-shutdown
# description: Shut down the system
# keywords: power off shutdown

gnome-session-quit --power-off