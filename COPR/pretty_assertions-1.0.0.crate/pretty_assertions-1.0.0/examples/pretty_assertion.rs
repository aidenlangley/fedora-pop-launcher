use pretty_assertions::assert_eq;

include!("standard_assertion.rs");
